export const RequestType = {
  get: 'GET',
  post: 'POST'
}