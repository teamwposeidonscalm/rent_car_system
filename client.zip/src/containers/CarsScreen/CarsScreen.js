import React from 'react'
import Card from '@material-ui/core/Card'
import CardContent from '@material-ui/core/CardContent'
import Typography from '@material-ui/core/Typography'
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import CarsTable from './CarsTable'

import { swapThemeColors, toggleThemeMode } from '../../store/reducers/settings'

const CarsScreen = props => {
  const {literals} = props

  return (
    <div>
      <Card>
        <CardContent>
          <Typography variant='headline'>{props.literals.cars}</Typography>
          <CarsTable />
        </CardContent>
      </Card>
    </div>)
}

const mapStateToProps = state => {
  return {
    settings: state.settings,
    literals: state.literals
  }
}

const mapDispatchToProps = dispatch => {
  return bindActionCreators(
    {
      toggleThemeMode: checked => toggleThemeMode(checked),
      swapThemeColors: checked => swapThemeColors(checked)
    },
    dispatch
  )
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(CarsScreen)
