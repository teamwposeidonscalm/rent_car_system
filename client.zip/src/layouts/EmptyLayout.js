import React from "react";

const EmptyLayout = props => {
  return <div style={{ height: "inherit" }}>{props.children}</div>;
};

export default EmptyLayout;
