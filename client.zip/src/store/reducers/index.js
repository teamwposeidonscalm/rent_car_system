import stepCounter from "./stepCounter";
import settings from "./settings";
import auth from "./authenticate";
import { combineReducers } from "redux";
import literals from "../literals";
import { reducer as formReducer } from "redux-form";

const reducers = combineReducers({
  stepCounter,
  settings,
  auth,
  literals,
  form: formReducer
});

export default reducers;
