import React from 'react'
import ReactDOM from 'react-dom'
import { Provider } from 'react-redux'
import registerServiceWorker from './registerServiceWorker'

import App from './App'
import store from './store'

import { loadLiterals } from './store/literals'
import loadLang from './i18n'

const lang = loadLang()
store.dispatch(loadLiterals(lang))

ReactDOM.render(
  <Provider store={store}>
    <App />
  </Provider>,
  document.getElementById('root')
)

registerServiceWorker()
