const cars = require('./cars');

module.exports = {
  cars
};